package RedBus.Pack3;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import RedBus.Pack1.TestBase;
import RedBus.Pack2.HomePage;

public class AccountPageTest extends TestBase {
	HomePage hp;

	@BeforeClass
	public void OpenApp() {
		openBrowser("Chrome");
		hp = new HomePage(driver);
	}

	@Test
	public void clickOnSignUpPage() throws InterruptedException {
		Thread.sleep(2000);
		hp.clickOnMyAccount();
		Thread.sleep(5000);
		hp.clickOnSignup();
		Thread.sleep(5000);
	}

	@AfterClass
	public void CloseApp() {
		driver.quit();
	}
}


